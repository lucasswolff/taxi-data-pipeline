import boto3
from urllib.parse import urlparse

def list_s3_files(months, folder_path): 
    s3 = boto3.client('s3')

    parsed = urlparse(folder_path)
    bucket_name = parsed.netloc
    prefix = parsed.path.lstrip('/')  # Remove leading '/' 

    # List all objects under the prefix
    response = s3.list_objects_v2(Bucket=bucket_name, Prefix=prefix)

    # Filter out directories (if any) and sort by LastModified
    files = sorted(
        [obj for obj in response.get('Contents', []) if not obj['Key'].endswith('/')],
        key=lambda x: x['LastModified']
    )

    # Get the last N files
    last_n = files[-months:]

    # Create full S3 paths
    file_paths = [f's3://{bucket_name}/{obj["Key"]}' for obj in last_n]

    return file_paths


def delete_s3_files(months, raw_folder_path, curated_folder_path):

    s3 = boto3.client('s3')
    bucket_name = 'taxi-data-hub'

    prefix_path = list_s3_files(months, raw_folder_path)

    delete_prefix_list = []

    for file in prefix_path:
        year, month = file.split('_')[2].replace('.parquet', '').split('-')
        
        file_to_delete = curated_folder_path.replace('s3://taxi-data-hub/', '') + 'file_year=' + year + '/file_month=' + month

        delete_prefix_list.append(file_to_delete)


    for prefix in delete_prefix_list:
        print(f"Deleting all objects under prefix: {prefix}")
        paginator = s3.get_paginator('list_objects_v2')
        pages = paginator.paginate(Bucket=bucket_name, Prefix=prefix)

        keys_to_delete = []
        for page in pages:
            for obj in page.get('Contents', []):
                keys_to_delete.append({'Key': obj['Key']})

        if keys_to_delete:
            response = s3.delete_objects(
                Bucket=bucket_name,
                Delete={'Objects': keys_to_delete}
            )
            print("Deleted:", response.get('Deleted', []))
            print("Errors:", response.get('Errors', []))
        else:
            print(f"No objects found under {prefix}")

