import sys
import os

running_on = 'AWS EMR'
#running_on = 'local' if spark.sparkContext.master.startswith("local") else 'AWS EMR'

if running_on == 'local':
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))


from curated.utils.create_spark import create_spark_session
from curated.transformations.taxi_transformer import TransformerBase, TransformerYellowGreen
from curated.tests.test_curated_taxi import run_tests
from curated.utils.read_lockup_tables import ReadLockup
from curated.transformations.transform_run_mode import TransformMode



def main(run_mode, months, trans_mode, raw_folder_path, lockup_folder_path, curated_folder_path):

    #### CREATE SPARK
    spark = create_spark_session(app_name="curated_layer")
    
    #### READ FILES
    print('Reading files...')
    
    taxi = 'green'
    file_path = trans_mode.get_run_mode_files(run_mode, months, raw_folder_path, taxi) # get file path based on run parameters
    
    print('Reading Raw')

    df_green_raw = spark.read.option("mergeSchema", "true").parquet(*file_path)

    print(df_green_raw.columns)
    
    print('reading Lockup tables')

    lockup_reader = ReadLockup()
    df_payment_type, df_ratecode, df_trip_type, df_taxi_zone = lockup_reader.read_lockup_tables(spark, lockup_folder_path)
    
    print('Successfully read all input tables!')

    #### TRANSFORM
    print('Initiating dataframe transformation...')
    
    transformer_green = TransformerYellowGreen()
    df_green = transformer_green.make_green_consistent(df_green_raw) # add columns with defaut values to be consistent with yellow taxi
    
    transformer = TransformerBase()
    df_green = transformer.transform_df(df_green, df_payment_type, df_ratecode, df_trip_type, df_taxi_zone) 

    #### TEST 
    run_tests(df_green)
    print('All tests passed!')    
    
    #### SAVE FILES
    print('Saving files...')
    
    if run_mode == 'full_load':
        df_green.coalesce(1).write \
            .partitionBy('file_year', 'file_month') \
            .mode('overwrite') \
            .parquet(curated_folder_path)
    

    else: 
        trans_mode.delete_parquet_folders(run_mode, months, curated_folder_path, raw_folder_path)
        
        df_green.coalesce(1).write \
            .partitionBy('file_year', 'file_month') \
            .mode('append') \
            .parquet(curated_folder_path)

    print('Successfully wrote files to Curated')
    
if __name__ == '__main__':

    trans_mode = TransformMode()
    run_mode, months = trans_mode.parse_args()
    
    # fazer vir automaticamente

    if running_on == 'local':
        raw_folder_path = "sample_data/raw/green/"
        lockup_folder_path = "lockup_tables/"
        curated_folder_path = "sample_data/curated/green"
        

    else:
        # mudar o path para secret
        raw_folder_path = "s3://taxi-data-hub/dev/raw/green/"
        lockup_folder_path = "s3://taxi-data-hub/dev/lockup_tables/"
        curated_folder_path = "s3://taxi-data-hub/dev/curated/green/"

    main(run_mode, months, trans_mode, raw_folder_path, lockup_folder_path, curated_folder_path)


