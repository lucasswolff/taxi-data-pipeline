import sys

script_path = sys.argv[0]

if 'transformations' in script_path:
    env = 'dev'
elif 'prd' in script_path:
    env = 'prd'
else:
    env = 'unknown'


print(env)